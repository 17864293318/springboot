package com.joyshebao.shiro.controller;

import com.joyshebao.shiro.model.User;
import com.joyshebao.shiro.service.UserService;
//import org.apache.shiro.SecurityUtils;
//import org.apache.shiro.authc.AuthenticationException;
//import org.apache.shiro.authc.IncorrectCredentialsException;
//import org.apache.shiro.authc.UnknownAccountException;
//import org.apache.shiro.authc.UsernamePasswordToken;
//import org.apache.shiro.subject.Subject;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.List;

@Controller
public class UserController {
    private UserService userService;

    @RequestMapping("/hello")
    public String hello(){
        System.out.println("Hello World");
        return "index";
    }
    @RequestMapping("/add")
    public String toAdd(){
        return "/user/add";
    }
    @RequestMapping("/update")
    public String toUpdate(){
        return "/user/update";
    }

    @RequestMapping("/tologin")
    public String toLogin(){
        return "/login";
    }

//    @RequestMapping("/login")
//    public String login(String name, String password, Model model){
//        //获取subject
//        Subject subject = SecurityUtils.getSubject();
//        //封装用户数据
//        UsernamePasswordToken token = new UsernamePasswordToken(name,password);
//        //执行登录方法
//        try {
//            //登录成功
//            subject.login(token);
//            return "redirect:/hello";
//        }catch (UnknownAccountException e){
//            //登录失败
////            e.printStackTrace();
//            model.addAttribute("msg","用户名不存在");
//            return "login";
//        }catch (IncorrectCredentialsException e){
//            model.addAttribute("msg","密码错误");
//            return "login";
//        }


//    }
    @RequestMapping("/userlist")
    @ResponseBody
    public List<User> getUserList(){
        return userService.getUserList();
    }
}
