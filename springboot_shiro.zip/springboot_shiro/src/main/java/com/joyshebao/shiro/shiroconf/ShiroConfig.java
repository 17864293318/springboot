//package com.joyshebao.shiro.shiroconf;
//
//
//import org.apache.shiro.spring.web.ShiroFilterFactoryBean;
//import org.apache.shiro.web.mgt.DefaultWebSecurityManager;
//import org.springframework.beans.factory.annotation.Qualifier;
//import org.springframework.context.annotation.Bean;
//import org.springframework.context.annotation.Configuration;
//
//import java.util.LinkedHashMap;
//import java.util.Map;
//
//@Configuration
//public class ShiroConfig {
//    //创建shirofilterFactoryBean
//    @Bean
//    public ShiroFilterFactoryBean getShiroFilterFactoryBean(@Qualifier("defaultWebSecurityManager") DefaultWebSecurityManager securityManager){
//        ShiroFilterFactoryBean shiroFilterFactoryBean = new ShiroFilterFactoryBean();
//        //设置安全管理器
//        shiroFilterFactoryBean.setSecurityManager(securityManager);
//        //添加shiro内置过滤器
//        /**
//         * anon:无需认证
//         * authc:必须认证
//         * user:如果使用rememberMe可以访问
//         * perms:必须得到权限才能访问
//         * role:必须得到角色权限
//         */
//        Map<String,String> filterMap = new LinkedHashMap<>();
////        filterMap.put("/add","authc");
//        filterMap.put("/update","authc");
//        filterMap.put("/getlist","anon");
////        filterMap.put("/hello","anon");
////        filterMap.put("/*","authc");
//
//        shiroFilterFactoryBean.setLoginUrl("/tologin");
//        shiroFilterFactoryBean.setFilterChainDefinitionMap(filterMap);
//        return shiroFilterFactoryBean;
//    }
//
//    //创建DefaultWebSecurityManagerBean
//    @Bean(name="defaultWebSecurityManager")
//    public DefaultWebSecurityManager getDefaultWebSecurityManager(@Qualifier("userShiroConfig") UserShiroConfig userRealm){
//        DefaultWebSecurityManager securityManager = new DefaultWebSecurityManager();
//        securityManager.setRealm(userRealm);
//        return securityManager;
//    }
//
//    //创建realm
//    @Bean(name="userShiroConfig")
//    public UserShiroConfig getRealm(){
//        return new UserShiroConfig();
//    }
//}
