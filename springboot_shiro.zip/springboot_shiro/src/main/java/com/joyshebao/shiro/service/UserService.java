package com.joyshebao.shiro.service;

import com.joyshebao.shiro.mapper.UserMapper;
import com.joyshebao.shiro.model.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UserService {
    @Autowired
    private UserMapper userMapper;

    public User findByName(String name){
        return  userMapper.findByName(name);
    }

    public List<User> getUserList(){
        return userMapper.getUserList();
    }
}
