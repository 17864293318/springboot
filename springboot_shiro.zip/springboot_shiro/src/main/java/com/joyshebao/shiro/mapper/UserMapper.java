package com.joyshebao.shiro.mapper;

import com.joyshebao.shiro.model.User;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

@Mapper
public interface UserMapper {
    public User findByName(String name);
    public List<User> getUserList();
}
